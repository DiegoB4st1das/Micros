################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (13.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/mpu6050/mpu6050.c 

OBJS += \
./Core/mpu6050/mpu6050.o 

C_DEPS += \
./Core/mpu6050/mpu6050.d 


# Each subdirectory must supply rules for building sources it contributes
Core/mpu6050/%.o Core/mpu6050/%.su Core/mpu6050/%.cyclo: ../Core/mpu6050/%.c Core/mpu6050/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m3 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32F103xB -c -I../Core/Inc -I../Drivers/STM32F1xx_HAL_Driver/Inc/Legacy -I../Drivers/STM32F1xx_HAL_Driver/Inc -I../Drivers/CMSIS/Device/ST/STM32F1xx/Include -I../Drivers/CMSIS/Include -I"C:/Users/diego/STM32CubeIDE/workspace_1.18.0/PruebaBalancin/Core/mpu6050" -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfloat-abi=soft -mthumb -o "$@"

clean: clean-Core-2f-mpu6050

clean-Core-2f-mpu6050:
	-$(RM) ./Core/mpu6050/mpu6050.cyclo ./Core/mpu6050/mpu6050.d ./Core/mpu6050/mpu6050.o ./Core/mpu6050/mpu6050.su

.PHONY: clean-Core-2f-mpu6050

