/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2025 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "common.h"
#include "lcd.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define ENCODER_PPR			(334)
#define PID_SAMPLING_RATE	(100)
#define PID_MAX_OUTPUT 1599
#define PID_MIN_OUTPUT -1599
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
/*
 * Eight-bit encoder state register
 * ----------------------------------------------
 * |	B7	B6	B5	B4	|	B3	B2	|	B1	B0	|
 * ----------------------------------------------
 * |	RESERVED		| NextState	| CurState	|
 * |					|-----------|-----------|
 * |					|ENCB* ENCA*|ENCB	ENCA|
 * |---------------------------------------------
 */
volatile uint8_t EncState = 0x00;
volatile int32_t EncPulseCounter = 0;

uint8_t menuAct = 0;

uint8_t botonPresionado = 0;
uint32_t tiempoInicio = 0;

char kPB[31];
char kIB[31];
char kDB[31];

// Initialize PID variables
float setPoint=1000;
float v=0;
//float u=0;
float eActual=0;
float ePrevio=0;
float ts=10;
float ppr=336;
float kP=0;
float kI=0;
float kD=0;
float eSuma=0;


// Define PID variables
//float Kp = 0.0F;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void HAL_PWM_SetDuty(uint32_t dc);
/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

void menu(uint8_t menuAct){
	LCD_Write(LCD_CMD_CLEAR,1);
	switch(menuAct){
	case 0:
		LCD_Goto_XY(0, 0);
		LCD_Print("Kp= ");
		float2str(kP, kPB, 1);
		LCD_Print(kPB);
		break;
	case 1:
		LCD_Goto_XY(0, 0);
		LCD_Print("Ki= ");
		float2str(kI ,kIB, 1);
		LCD_Print(kIB);
		break;
	case 2:
		LCD_Goto_XY(0, 0);
		LCD_Print("Kd= ");
		float2str(kD ,kDB, 1);
		LCD_Print(kDB);
		break;
	}
}

void EXTI15_10_IRQHandler(void)
{
	if(EXTI->PR & EXTI_PR_PIF10 || EXTI->PR & EXTI_PR_PIF11)
	{
		// Clear EXTI10 & EXTI11 flags by writing 1
		EXTI->PR = EXTI_PR_PIF10 | EXTI_PR_PIF11;

		// Compute next state
		uint8_t nextState = EncState & 0x03;	// Clear next state bit-field
		if (ENCA_GPIO_Port->IDR & ENCA_Pin) nextState |= (1 << 2);
		if (ENCA_GPIO_Port->IDR & ENCB_Pin) nextState |= (1 << 3);

		// Update the pulse counter
		/*                        _______         _______
		 *               A ______|       |_______|       |______ A
		 * negative <---      _______         _______         __      --> positive
		 *               B __|       |_______|       |_______|   B
		 *
		 *
		 * |	HEX	|	B*	A*	|	B	A	|	Operation
		 * |--------|-----------|-----------|-------------
		 * |  0x00	|	0	0	|	0	0	|	IDLE
		 * |  0x01	|	0	0	|	0	1	|	+1
		 * |  0x02	|	0	0	|	1	0	|	-1
		 * |  0x03	|	0	0	|	1	1	|   +2
		 * |  0x04	|	0	1	|	0	0	|	-1
		 * |  0x05	|	0	1	|	0	1	|	IDLE
		 * |  0x06	|	0	1	|	1	0	|	-2
		 * |  0x07	|	0	1	|	1	1	|	+1
		 * |  0x08	|	1	0	|	0	0	|	+1
		 * |  0x09	|	1	0	|	0	1	|	-2
		 * |  0x0A	|	1	0	|	1	0	|	IDLE
		 * |  0x0B	|	1	0	|	1	1	|	-1
		 * |  0x0C	|	1	1	|	0	0	|	+2
		 * |  0x0D	|	1	1	|	0	1	|	-1
		 * |  0x0E	|	1	1	|	1	0	|	+1
		 * |  0x0F	|	1	1	|	1	1	|	IDLE
		 * |--------|-----------|-----------|-------------
		 */
		switch(nextState)
		{
			case 0x01: case 0x07: case 0x08: case 0x0E:
				EncPulseCounter++;
			break;

			case 0x02: case 0x04: case 0x0B: case 0x0D:
				EncPulseCounter--;
			break;

			case 0x03: case 0x0C:
				EncPulseCounter += 2;
			break;

			case 0x06: case 0x09:
				EncPulseCounter -= 2;
			break;
		}

		// Update current state with next state
		EncState = nextState >> 2;
	}
}
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */

  LCD_Init(LCD_4BITS_INTERFACE);
  menu(menuAct);


  // Set current encoder state
  if (ENCA_GPIO_Port->IDR & ENCA_Pin) EncState |= 0x01;
  if (ENCA_GPIO_Port->IDR & ENCB_Pin) EncState |= 0x02;

  // Hardware
  SysTick_Config(SystemCoreClock / 1000); 		// Systick to 1ms
  HAL_TIM_PWM_Start(&htim3, TIM_CHANNEL_1);		// Start TIM3.PWM.CH1

  // Enable EXTI15_10 Interrupts
  HAL_NVIC_SetPriority(EXTI15_10_IRQn, 0, 0);
  HAL_NVIC_EnableIRQ(EXTI15_10_IRQn);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  uint32_t ulPIDLastTimeWake = HAL_GetTick(); // Get current time in milliseconds
  int32_t lEncPrevCount = 0; //Q[n-1]
  while (1)
  {
	  // Check if PID algorithm must be applied
	  if((HAL_GetTick()-ulPIDLastTimeWake) > 1000/PID_SAMPLING_RATE)
	  {
		  // Get current time
		  ulPIDLastTimeWake = HAL_GetTick();

		  // Get the current encoder pulse counter
		  __disable_irq();
		  int32_t lEncCount = EncPulseCounter; // Q[n]
		  __enable_irq();

		  // Compute angular speed (RPMs) x[n] = ([CurrentCount - PrevCount]/Ts) * 60 / PPR
		  //float fMotorSpeed;

		  // Update previous encoder pulse counter with the current encoder pulse counter
		  lEncPrevCount = lEncCount;



		  // Apply PID algorithm with x[n] = current angular speed
		  v= ((float)(lEncCount-lEncPrevCount)/(ts*ppr))*60;

		  // u[n] = Kp*e[n] + Ki*(ErrorSum[n-1] + e[n])*Ts + Kd*(e[n] - e[n-1])/Ts
		  //=u(kP*eActual)+(ts*kI*(eSuma+eActual))+((kD*(eActual-ePrevio))/ts);

		  // Where e[n] = SetPoint - x[n]
		  eActual=setPoint-v;

		  // Ts: PID Sampling Period
		  float fPwmControl=(kP*eActual)+(ts*kI*(eSuma+eActual))+((kD*(eActual-ePrevio))/ts); // u[n]

		  ePrevio=eActual;
		  eSuma+=eActual;

		  // Saturate the output
		  if(fPwmControl > PID_MAX_OUTPUT) fPwmControl = PID_MAX_OUTPUT;
		  else if(fPwmControl < PID_MIN_OUTPUT) fPwmControl = PID_MIN_OUTPUT;

		  // Change the motor direction if needed based on the sign of the fPwmControl
		  if(fPwmControl < 0.0F)
		  {
			  // Set motor backward direction on L298N
			  HAL_GPIO_WritePin(IN1_GPIO_Port,IN1_Pin ,GPIO_PIN_RESET );
			  HAL_GPIO_WritePin(IN2_GPIO_Port,IN2_Pin ,GPIO_PIN_SET );
			  // Change to positive
			  fPwmControl = -fPwmControl;
		  }
		  else
		  {
			  // Set motor forward direction on L298N
			  HAL_GPIO_WritePin(IN1_GPIO_Port,IN1_Pin ,GPIO_PIN_SET );
			  HAL_GPIO_WritePin(IN2_GPIO_Port,IN2_Pin ,GPIO_PIN_RESET );
		  }

		  // Update duty cycle
		  HAL_PWM_SetDuty((uint32_t)fPwmControl);
	  }

	  //BOTOOOON

	  if (HAL_GPIO_ReadPin(Boton_GPIO_Port, Boton_Pin) == GPIO_PIN_RESET){
		  //HAL_Delay(5);// Botón presionado
		  uint8_t debouncing = HAL_GetTick();
		  if((HAL_GetTick()-debouncing) >= 5){

			  if (botonPresionado == 0){ // Detecta el inicio de la pulsación

				  tiempoInicio = HAL_GetTick();
				  botonPresionado = 1;
			  }
		  }
	  }
	  else{ // Botón liberado

		  if (botonPresionado == 1){ // Se soltó el botón

			  uint32_t duracion = HAL_GetTick() - tiempoInicio;

			  if (duracion < 250){

				  switch (menuAct){
				  case 0:
					  kP+=0.1;
					  break;
				  case 1:
					  kI+=0.1;
					  break;
				  case 2:
					  kD+=0.1;
					  break;

				  }
				  menu(menuAct);
			  }
			  else if (duracion >= 750) {
				  switch (menuAct){
				  case 0:
					  menuAct=1;
					  break;
				  case 1:
					  menuAct=2;
					  break;
				  case 2:
					  menuAct=0;
					  break;
				  }

				  menu(menuAct);

			  }
			  botonPresionado = 0; // Reinicia el estado
		  }

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
	  }
  /* USER CODE END 3 */
  }
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_PWM_SetDuty(uint32_t dc)
{
	if(dc > TIM3->ARR) TIM3->CCR1 = TIM3->ARR;
	else TIM3->CCR1 = dc;
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void){
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
//''  /* USER CODE END Error_Handler_Debug */

}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
